# IT Network Troubleshooting Assistant

A beginner-friendly Python project that demonstrates how Python can be used to assist with common IT network troubleshooting tasks.

## Project objective

The goal of this project is to connect Python programming with practical IT support and networking scenarios.

## Features

- Check local IP configuration
- Ping an IP address or hostname
- Perform DNS lookup
- Run a basic combined network diagnostic
- Menu-driven command-line interface
- Basic exception handling
- Cross-platform handling for common ping commands

## Technologies

- Python 3
- Python `subprocess`
- Python `socket`
- Python `platform`
- Networking fundamentals
- Command-line troubleshooting

## Project structure

```text
IT-Network-Troubleshooting-Assistant/
│
├── main.py
├── network_utils.py
├── README.md
└── screenshots/
    └── README.md
```

## How to run

1. Install Python 3.
2. Download or clone this repository.
3. Open a terminal in the project folder.
4. Run:

```bash
python main.py
```

On some systems you may need:

```bash
python3 main.py
```

## Example workflow

```text
1. Check IP configuration
2. Test gateway / host with ping
3. Test DNS lookup
4. Run full diagnostics
5. Exit
```

## Important note

The project performs basic diagnostics. It does not automatically repair network problems. It is intended as a learning and portfolio project.

## Future improvements

- Automatic default-gateway detection
- Better Windows/Linux/macOS support
- Logging diagnostic results to a file
- Exporting reports
- GUI version
- Automated troubleshooting recommendations
- Unit tests
