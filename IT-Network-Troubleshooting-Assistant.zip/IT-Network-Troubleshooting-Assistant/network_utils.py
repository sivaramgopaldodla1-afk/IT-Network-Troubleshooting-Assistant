"""
Network diagnostic helper functions.

The commands used here are intended for basic troubleshooting.
Some command output differs between Windows and Linux/macOS.
"""

import platform
import socket
import subprocess


def _run_command(command):
    """Run a local diagnostic command and return its output."""
    completed = subprocess.run(
        command,
        capture_output=True,
        text=True,
        timeout=15,
        shell=False,
    )

    output = completed.stdout.strip()
    error = completed.stderr.strip()

    if output:
        return output
    if error:
        return error
    return "Command completed with no output."


def get_ip_configuration():
    """Display the computer's IP configuration."""
    system = platform.system().lower()

    if system == "windows":
        return _run_command(["ipconfig", "/all"])

    return _run_command(["ifconfig"])


def ping_host(host):
    """Ping a host once and return the command output."""
    system = platform.system().lower()

    if system == "windows":
        command = ["ping", "-n", "1", host]
    else:
        command = ["ping", "-c", "1", host]

    return _run_command(command)


def dns_lookup(host):
    """Resolve a hostname to an IP address using Python's socket module."""
    try:
        addresses = socket.gethostbyname_ex(host)
        hostname, aliases, ip_addresses = addresses

        return (
            f"Hostname: {hostname}\n"
            f"Aliases: {aliases if aliases else 'None'}\n"
            f"IP addresses: {', '.join(ip_addresses)}"
        )
    except socket.gaierror:
        return f"DNS resolution failed for: {host}"


def run_full_diagnostics():
    """Run a small set of network checks."""
    sections = []

    sections.append("=== IP CONFIGURATION ===")
    sections.append(get_ip_configuration())

    sections.append("\n=== GATEWAY / CONNECTIVITY TEST ===")
    sections.append(ping_host("8.8.8.8"))

    sections.append("\n=== DNS TEST ===")
    sections.append(dns_lookup("google.com"))

    return "\n".join(sections)
