# Screenshots

Add screenshots here after you run the application on your computer.

Recommended screenshots:

1. `menu.png` — show the main application menu.
2. `result.png` — show a successful diagnostic result.

Do not upload screenshots that contain passwords, private IP information you do not want public, usernames, email addresses, or other sensitive information.
